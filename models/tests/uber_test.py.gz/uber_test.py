from uberpy import Uber
    
uber = Uber('MuasbGEmW07jGkPZdpKJe9e-4YMNGVSEtoCMmgAE', 'TMRHMtGjNg6qbBxoitItOl9_6cAYkh2u', '9mRWqWlmZaarD_pYpw2vsipa_dB75DjispQsXMd_')

latitude = 51.5286416
longitude = -0.1015987

uber_products = uber.get_products(latitude, longitude)
