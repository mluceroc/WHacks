import requests
from rauth import OAuth2Service

uber_api = OAuth2Service(
     client_id='MuasbGEmW07jGkPZdpKJe9e-4YMNGVSEtoCMmgAE',
     client_secret='9mRWqWlmZaarD_pYpw2vsipa_dB75DjispQsXMd_',
     name='HubHop',
     authorize_url='https://localhost/',
     access_token_url='https://login.uber.com/oauth/token',
     base_url='https://api.uber.com/v1/',
 )

parameters = {
    'response_type': 'code',
    'redirect_uri': 'https://localhost/',
    'scope': 'profile',
}

# Redirect user here to authorize your application
login_url = uber_api.get_authorize_url(**parameters)

print login_url


url = 'https://api.uber.com/v1/products'

parameters = {
    'server_token': 'TMRHMtGjNg6qbBxoitItOl9_6cAYkh2u',
    'latitude': 37.775818,
    'longitude': -122.418028,
}

response = requests.get(url, params=parameters)

data = response.json()

print data